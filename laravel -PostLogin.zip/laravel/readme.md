Simple Hello World app using Docker, PHP, Laravel and MySql


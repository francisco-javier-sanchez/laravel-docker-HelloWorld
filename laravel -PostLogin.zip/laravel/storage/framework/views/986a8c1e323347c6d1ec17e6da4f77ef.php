<?php $__env->startSection('content'); ?>
<main class="login-form">
    <div class="container">
	<div class="row justify-content-center">
	    <div class="col-md-4">
		<div class="card">
		    <h1>USUARIO LOGEADO CORRECTAMENTE</h1>
		</div>
	    </div>
	</div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/logged.blade.php ENDPATH**/ ?>
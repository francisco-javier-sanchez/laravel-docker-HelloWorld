@extends('app')
@section('content')
<main class="login-form">
    <div class="container">
	<div class="row justify-content-center">
	    <div class="col-md-4">
		<div class="card">
		    <h1>USUARIO LOGEADO CORRECTAMENTE</h1>
		</div>
	    </div>
	</div>
    </div>
</main>
@endsection
